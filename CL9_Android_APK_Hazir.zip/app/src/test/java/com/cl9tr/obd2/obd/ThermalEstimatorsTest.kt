package com.cl9tr.obd2.obd

import org.junit.Assert.assertTrue
import org.junit.Test

class ThermalEstimatorsTest {

    @Test
    fun scenario1_coldStart20MinWarmup_oilLagsBehindCoolant() {
        val eot = VirtualEOTEstimator(ThermalConfig())
        var ect = 20.0
        var eotAt6Min = 20.0
        var eotAt15Min = 20.0

        for (sec in 1..1200) {
            ect = if (sec <= 360) 20.0 + (65.0 * (sec / 360.0)) else 88.0
            val reading = eot.update(
                ThermalSampleInput(ectC = ect, iatC = 18.0, rpm = 2200.0, mapKpa = 45.0, tpsPct = 22.0, speedKmh = 60.0, dtSec = 1.0)
            )
            if (sec == 360) eotAt6Min = reading.temperatureC
            if (sec == 900) eotAt15Min = reading.temperatureC
        }

        // 6. dakikada ECT 85°C iken yağ henüz belirgin şekilde geride olmalı
        assertTrue("6. dakikada yağ sudan geride olmalı (EOT=$eotAt6Min)", eotAt6Min < 75.0)
        // 15. dakikada yağ 80-92°C ideal çalışma bandına oturmalı
        assertTrue("15. dakikada yağ 80°C üzerine oturmalı (EOT=$eotAt15Min)", eotAt15Min >= 80.0)
    }

    @Test
    fun scenario2_highRpmVtecLoad_oilExceedsCoolant() {
        val eot = VirtualEOTEstimator(ThermalConfig())
        var lastEot = 85.0
        // Sıcak başlangıç (ECT=90°C) ardından 6 dakika yüksek devir/yük sürüşü
        for (sec in 1..360) {
            val reading = eot.update(
                ThermalSampleInput(ectC = 90.0, iatC = 35.0, rpm = 6200.0, mapKpa = 94.0, tpsPct = 88.0, speedKmh = 110.0, gyroStrainG = 0.45, dtSec = 1.0)
            )
            lastEot = reading.temperatureC
        }
        assertTrue("Yüksek devir ve yükte yağ sıcaklığı ECT'yi (90°C) geçmeli (EOT=$lastEot)", lastEot > 98.0)
    }

    @Test
    fun scenario3_stopAndGoHillHeatsAtf_highwayLockupCoolsAtf() {
        val monitor = ATFMonitor(probe = object : HondaTcmAtfProbe {
            override fun probeAtfTempC(): Double? = null // TCM yanıt yok -> Sanal ATF
        })
        var peakCityAtf = 0.0
        // 8 dakika şehir içi dur-kalk yokuş trafiği
        for (sec in 1..480) {
            val r = monitor.update(
                ThermalSampleInput(ectC = 92.0, iatC = 32.0, rpm = 2600.0, mapKpa = 78.0, tpsPct = 42.0, speedKmh = 18.0, gyroStrainG = 0.35, dtSec = 1.0)
            )
            assertTrue(r.isEstimated)
            if (r.temperatureC > peakCityAtf) peakCityAtf = r.temperatureC
        }
        // 8 dakika otoyol 100 km/sa Lock-Up sürüşü
        var highwayAtf = peakCityAtf
        for (sec in 1..480) {
            val r = monitor.update(
                ThermalSampleInput(ectC = 88.0, iatC = 28.0, rpm = 2150.0, mapKpa = 44.0, tpsPct = 20.0, speedKmh = 100.0, gyroStrainG = 0.05, dtSec = 1.0)
            )
            highwayAtf = r.temperatureC
        }
        assertTrue("Dur-kalk yokuşta ATF ısınmalı ($peakCityAtf)", peakCityAtf > 98.0)
        assertTrue("Otoyol Lock-Up sürüşünde ATF soğumalı (peak=$peakCityAtf -> hwy=$highwayAtf)", highwayAtf < peakCityAtf - 6.0)
    }
}
