package com.cl9tr.obd2.obd

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.IBinder
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import androidx.core.app.NotificationCompat
import com.cl9tr.obd2.MainActivity
import com.cl9tr.obd2.R

/**
 * CL9 Arka Plan Ön Plan Servisi (Foreground Service).
 * Uygulama arka plana alındığında OBD-II bağlantısını ve sürüş verilerini canlı tutar,
 * bildirim ekranında saatlik tahmini şarj tüketimi ve kırmızı "Sonlandır" butonu gösterir.
 */
class Cl9BackgroundService : Service() {

    companion object {
        const val CHANNEL_ID = "cl9_background_obd_channel"
        const val NOTIFICATION_ID = 9024
        const val EXTRA_CONFIRM_EXIT = "com.cl9tr.obd2.EXTRA_CONFIRM_EXIT"
        const val ACTION_STOP_SERVICE = "com.cl9tr.obd2.ACTION_STOP_SERVICE"

        fun start(context: Context) {
            val intent = Intent(context, Cl9BackgroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, Cl9BackgroundService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this, 100, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Kırmızı "Sonlandır" butonu uygulamayı açıp "Emin misiniz?" onay penceresini tetikler
        val exitPromptIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_CONFIRM_EXIT, true)
        }
        val exitPromptPending = PendingIntent.getActivity(
            this, 101, exitPromptIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val redStopLabel = SpannableString("Sonlandır").apply {
            setSpan(ForegroundColorSpan(Color.parseColor("#EF4444")), 0, length, 0)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("CL9 Arka Planda Çalışıyor")
            .setContentText("OBD-II bağlantısı aktif • Saatte ~%4,5 şarj tüketir")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("CL9 arka planda çalışmaya devam ediyor.\nTahmini pil tüketimi: saatte ~%4,5 şarj tüketir.")
            )
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPending)
            .addAction(0, redStopLabel, exitPromptPending)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "CL9 Arka Plan OBD-II Servisi",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "CL9 arka planda çalışırken kalıcı durum ve şarj tüketimi bildirimi gösterir."
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
