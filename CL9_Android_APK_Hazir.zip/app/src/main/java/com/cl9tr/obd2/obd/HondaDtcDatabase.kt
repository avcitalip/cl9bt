package com.cl9tr.obd2.obd

import com.cl9tr.obd2.model.DtcCode
import java.util.Locale

object HondaDtcDatabase {

    private data class DtcEntry(val system: String, val desc: String, val note: String)

    private val db: Map<String, DtcEntry> = mapOf(
        // === HAVA / YAKIT & OKSİJEN (A/F WIDEBAND + B1S2) ===
        "P0107" to DtcEntry("Motor (K24A3)", "MAP Sensörü Düşük Voltaj", "Emme manifoldu MAP sensörü soketini, vakum hattını ve 5V beslemesini kontrol edin."),
        "P0108" to DtcEntry("Motor (K24A3)", "MAP Sensörü Yüksek Voltaj", "MAP sensörü kısa devresi, şase kopukluğu veya arızalı MAP sensörü."),
        "P0112" to DtcEntry("Motor (K24A3)", "Emiş Hava Sıcaklığı (IAT) Sensörü Düşük Voltaj", "Hava filtresi hortumu üzerindeki IAT sensörü kısa devre yapmış olabilir."),
        "P0113" to DtcEntry("Motor (K24A3)", "Emiş Hava Sıcaklığı (IAT) Sensörü Yüksek Voltaj", "IAT sensörü soketi çıkmış, kablo kopuk veya sensör açık devre."),
        "P0116" to DtcEntry("Motor (K24A3)", "Motor Soğutma Sıvısı (ECT1) Aralık/Performans", "Termostat açık takılı kalmış veya ECT1 sensörü hatalı okuyor olabilir."),
        "P0117" to DtcEntry("Motor (K24A3)", "Motor Soğutma Sıvısı (ECT1) Düşük Voltaj", "ECT1 (37870-PNA-003) kısa devre; soğutma göstergesi ve fan kontrolünü etkiler."),
        "P0118" to DtcEntry("Motor (K24A3)", "Motor Soğutma Sıvısı (ECT1) Yüksek Voltaj", "ECT1 soketi gevşek/kopuk veya sensör açık devre."),
        "P0122" to DtcEntry("Motor (K24A3)", "Gaz Kelebeği Konum Sensörü (TPS) Düşük Voltaj", "Elektronik gaz kelebeği (DBW) TPS A kanalı düşük voltaj; soket ve tesisatı kontrol edin."),
        "P0123" to DtcEntry("Motor (K24A3)", "Gaz Kelebeği Konum Sensörü (TPS) Yüksek Voltaj", "DBW gaz kelebeği TPS A kanalı yüksek voltaj/açık devre."),
        "P0128" to DtcEntry("Motor (K24A3)", "Soğutma Sıvısı Termostat Sıcaklığının Altında", "CL9'da termostat erken açıyor veya açık takılı kalmış; yakıt tüketimini artırır."),
        "P0134" to DtcEntry("Motor (K24A3)", "Ön Geniş Bant Oksijen (A/F) Sensörü Aktivite Yok (B1S1)", "2004 CL9'da orijinal Denso/NTK LAF sensörü ve ısıtıcı soketini kontrol edin."),
        "P0135" to DtcEntry("Motor (K24A3)", "Ön A/F Sensörü Isıtıcı Devresi Arızası (B1S1)", "B1S1 sensör ısıtıcı direnci (2-4 ohm), LAF rölesi veya sigorta kontrolü gerekir."),
        "P0137" to DtcEntry("Motor (K24A3)", "Arka Oksijen Sensörü (B1S2) Düşük Voltaj", "Katalizör sonrası O2 sensörü kablosu şaseye temas ediyor veya sensör zayıflamış."),
        "P0138" to DtcEntry("Motor (K24A3)", "Arka Oksijen Sensörü (B1S2) Yüksek Voltaj", "Katalizör sonrası B1S2 sensör kısa devresi veya aşırı zengin karışım."),
        "P0139" to DtcEntry("Motor (K24A3)", "Arka Oksijen Sensörü (B1S2) Yavaş Tepki", "Katalizör sonrası O2 sensörü yaşlanmış veya egzozda kaçak var."),
        "P0141" to DtcEntry("Motor (K24A3)", "Arka Oksijen Sensörü (B1S2) Isıtıcı Devresi Arızası", "B1S2 ısıtıcı bobini açık devre; orijinal Denso sensörle değişim gerekir."),
        "P0171" to DtcEntry("Motor (K24A3)", "Sistem Çok Fakir (Bank 1)", "Emme vakum kaçağı, LPG fakir ayarı, düşük yakıt basıncı veya kirli enjektör. STFT+LTFT izleyin."),
        "P0172" to DtcEntry("Motor (K24A3)", "Sistem Çok Zengin (Bank 1)", "LPG zengin haritası, kaçıran benzin enjektörü veya hatalı ön A/F sensörü."),
        "P1128" to DtcEntry("Motor (K24A3)", "MAP Sensörü Beklenenden Düşük Basınç", "Emme manifoldu sensörü veya gaz kelebeği adaptasyon sapması."),
        "P1129" to DtcEntry("Motor (K24A3)", "MAP Sensörü Beklenenden Yüksek Basınç", "Emme manifoldu vakum kaçağı, açık kalan EGR veya sübap ayarı sıkılığı."),
        "P1157" to DtcEntry("Motor (K24A3)", "Ön A/F (Wideband) Sensörü Devre Yüksek Voltaj (B1S1)", "2004 CL9 K24A3'te çok yaygın koddur: Ön A/F sensörü (AFS) hattı açık/yüksek voltaj. Orijinal Denso 234-9040 sensör, soket oksitlenmesi ve LAF rölesini kontrol edin."),
        "P1166" to DtcEntry("Motor (K24A3)", "Ön A/F Sensörü Isıtıcı Sistem Elektrik Arızası", "B1S1 A/F ısıtıcı devresi, sigorta veya sensör içi ısıtıcı kopukluğu."),
        "P1167" to DtcEntry("Motor (K24A3)", "Ön A/F Sensörü Isıtıcı Sistem Arızası", "B1S1 A/F ısıtıcısı çalışma sıcaklığına ulaşamıyor; sensör değişimi gerekebilir."),
        "P1172" to DtcEntry("Motor (K24A3)", "Ön A/F Sensörü Devresi Aralık Dışı (Yüksek)", "A/F sensörü sinyal sapması; egzoz manifoldu kaçağı veya sensör ömrü sonu."),
        "P2195" to DtcEntry("Motor (K24A3)", "Ön A/F Sensörü Fakirde Takılı Kaldı (B1S1)", "Vakum kaçağı, yakıt kesintisi, LPG enjektör arızası veya arızalı A/F sensörü."),
        "P2237" to DtcEntry("Motor (K24A3)", "Ön A/F Sensörü Pompa Akım Devresi Açık (B1S1)", "B1S1 sensör tesisat kopukluğu veya sensör arızası."),
        "P2238" to DtcEntry("Motor (K24A3)", "Ön A/F Sensörü Pompa Akım Devresi Düşük", "B1S1 sensör soketi veya sensör içi kısa devre."),
        "P2251" to DtcEntry("Motor (K24A3)", "Ön A/F Sensörü Referans Şase Devresi Açık", "B1S1 şase hattı veya sensör soketi kontrolü gerekir."),
        "P2279" to DtcEntry("Motor (K24A3)", "Emme Havası Sisteminde Kaçak Algılandı", "Hava filtresi körüğü çatlağı (CL9'da kroniktir!), PCV hortumu veya emme contası."),

        // === ENJEKTÖR & AŞIRI DEVİR ===
        "P0201" to DtcEntry("Motor (K24A3)", "1. Silindir Enjektör Devresi Arızası", "1. silindir benzin enjektörü veya LPG kesici emülatör tesisatı kontrolü."),
        "P0202" to DtcEntry("Motor (K24A3)", "2. Silindir Enjektör Devresi Arızası", "2. silindir benzin enjektörü veya LPG emülatör bağlantısı."),
        "P0203" to DtcEntry("Motor (K24A3)", "3. Silindir Enjektör Devresi Arızası", "3. silindir benzin enjektörü veya LPG emülatör bağlantısı."),
        "P0204" to DtcEntry("Motor (K24A3)", "4. Silindir Enjektör Devresi Arızası", "4. silindir benzin enjektörü veya LPG emülatör bağlantısı."),
        "P0219" to DtcEntry("Motor (K24A3)", "Motor Aşırı Devir Durumu (Engine Overspeed)", "Motor, K24A3 izin verilen maksimum devir sınırını (kesici / triptronik sert vites küçültme) aştı. Motor sağlığı için sübap/zincir sesi kontrol edilip kod temizlenmelidir."),
        "P0222" to DtcEntry("Motor (K24A3)", "Gaz Kelebeği Konum Sensörü B Düşük Voltaj", "DBW gaz kelebeği B kanalı düşük sinyal."),
        "P0223" to DtcEntry("Motor (K24A3)", "Gaz Kelebeği Konum Sensörü B Yüksek Voltaj", "DBW gaz kelebeği B kanalı yüksek sinyal."),

        // === ATEŞLEME, VURUNTU & ZİNCİR/FAZ ===
        "P0300" to DtcEntry("Motor (K24A3)", "Rastgele / Çoklu Silindir Teklemesi", "Buji, bobin, sübap ayarı (K24A3 LPG'de 40.000 km'de bir kritik!) ve yakıt kalitesini kontrol edin."),
        "P0301" to DtcEntry("Motor (K24A3)", "1. Silindir Ateşleme Teklemesi", "1. silindir bobinini ve iridyum bujiyi diğer silindirle yer değiştirerek test edin."),
        "P0302" to DtcEntry("Motor (K24A3)", "2. Silindir Ateşleme Teklemesi", "2. silindir bobini, buji ve LPG enjektörünü kontrol edin."),
        "P0303" to DtcEntry("Motor (K24A3)", "3. Silindir Ateşleme Teklemesi", "3. silindir bobini, buji ve LPG enjektörünü kontrol edin."),
        "P0304" to DtcEntry("Motor (K24A3)", "4. Silindir Ateşleme Teklemesi", "4. silindir bobini, buji ve LPG enjektörünü kontrol edin."),
        "P0325" to DtcEntry("Motor (K24A3)", "Vuruntu (Knock) Sensörü Devre Arızası", "K24A3'te emme manifoldu altındaki knock sensörü kırılması/nemlenmesi çok yaygındır."),
        "P0335" to DtcEntry("Motor (K24A3)", "Krank Mili Konum Sensörü (CKP) Devre Arızası", "Krank sensörü (CKP) veya kablosu; motor geç çalışma/stop etme yapabilir."),
        "P0339" to DtcEntry("Motor (K24A3)", "Krank Mili Konum Sensörü (CKP) Kesintili Sinyal", "CKP sensörü aralıklı kesinti yapıyor; soket ve sensör kontrolü gerekir."),
        "P0340" to DtcEntry("Motor (K24A3)", "Eksantrik Mili Konum Sensörü A (CMP) Arızası", "Emme eksantrik sensörü (CMP A) soketi veya sensör arızası."),
        "P0341" to DtcEntry("Motor (K24A3)", "Eksantrik (CMP) / Krank Faz Uyumsuzluğu", "K24A3 triger zinciri uzaması, gergi zayıflaması veya VTC aktüatörü kontrolü kritik önem taşır!"),
        "P1399" to DtcEntry("Motor (K24A3)", "Geçici / Bekleyen Rastgele Silindir Teklemesi (Honda)", "Honda'ya özel erken tekleme uyarısı: Sübap ayarı, buji boşluğu ve bobin izolasyonunu kontrol edin."),

        // === EMİSYON, EGR, KATALİZÖR & EVAP ===
        "P0401" to DtcEntry("Motor (K24A3)", "Yetersiz EGR Akışı", "EGR valfi ve emme manifoldu EGR kanallarında kurum tıkanıklığı."),
        "P0404" to DtcEntry("Motor (K24A3)", "EGR Valfi Konum/Aralık Performans Arızası", "EGR valfi kurumdan dolayı tam açılıp kapanamıyor; temizlik veya değişim gerekir."),
        "P0420" to DtcEntry("Motor (K24A3)", "Katalitik Konvertör Verimi Eşik Altında", "Arka B1S2 O2 sensörü voltajı ön sensörle birlikte dalgalanıyorsa katalizör verimi düşmüştür."),
        "P0441" to DtcEntry("Motor (K24A3)", "EVAP Yakıt Buharı Tahliye Akışı Hatalı", "Kanister tahliye (purge) valfi kontrolü."),
        "P0443" to DtcEntry("Motor (K24A3)", "EVAP Tahliye Kontrol Valfi Devre Arızası", "Purge solenoid valfi soketi veya bobini."),
        "P0455" to DtcEntry("Motor (K24A3)", "EVAP Sisteminde Büyük Buhar Kaçağı", "Yakıt depo kapağı gevşek veya kanister hortumu çıkmış olabilir."),
        "P0456" to DtcEntry("Motor (K24A3)", "EVAP Sisteminde Küçük Buhar Kaçağı", "Depo kapağı contası veya ince EVAP hortum çatlağı."),
        "P0497" to DtcEntry("Motor (K24A3)", "EVAP Düşük Tahliye Akışı", "Kanister valfi veya iki yönlü basınç valfi tıkanıklığı."),
        "P1456" to DtcEntry("Motor (K24A3)", "EVAP Yakıt Deposu Tarafı Kaçağı (Honda)", "Genellikle depo kapağının tam sıkılmaması veya contanın eskimesinden kaynaklanır."),
        "P1457" to DtcEntry("Motor (K24A3)", "EVAP Kanister Tarafı Kaçağı (Honda)", "Kanister tahliye/havalandırma solenoidi (CVS) kontrolü."),

        // === RÖLANTİ, ELEKTRONİK GAZ KELEBEĞİ (DBW), i-VTEC & ŞARJ ===
        "P0505" to DtcEntry("Motor (K24A3)", "Rölanti Kontrol Sistemi Arızası", "Gaz kelebeği kurum temizliği sonrası rölanti öğrenme (Idle Relearn) yapılmalıdır."),
        "P0507" to DtcEntry("Motor (K24A3)", "Rölanti Devri Beklenenden Yüksek", "Emme vakum kaçağı veya temizlik sonrası DBW rölanti adaptasyon eksikliği."),
        "P0562" to DtcEntry("Motor (K24A3)", "Sistem Akü Voltajı Düşük", "Akü zayıf veya alternatör şarj regülatörü yetersiz (13.6V altı kontrol edilmeli)."),
        "P0563" to DtcEntry("Motor (K24A3)", "Sistem Akü Voltajı Yüksek", "Alternatör konjektörü aşırı şarj yapıyor (14.8V üstü tehlikelidir)."),
        "P0606" to DtcEntry("Motor (K24A3)", "ECU / PCM İşlemci Hatası", "Akü voltaj düşüklüğü veya ECU besleme rölesi kontrol edilmelidir."),
        "P1009" to DtcEntry("Motor (K24A3)", "VTC İlerleme / Zamanlama Arızası (i-VTEC)", "Motor yağ seviyesi, VTC yağ süzgeci ve VTC solenoidini kontrol edin."),
        "P1259" to DtcEntry("Motor (K24A3)", "VTEC Sistem Arızası (Honda)", "Düşük motor yağı seviyesi, tıkalı VTEC süzgeci veya VTEC solenoid arızası."),
        "P1297" to DtcEntry("Motor (K24A3)", "Elektrik Yük Dedektörü (ELD) Düşük Voltaj", "Motor içi sigorta kutusundaki Honda ELD modülü (ekonomik parça)."),
        "P1298" to DtcEntry("Motor (K24A3)", "Elektrik Yük Dedektörü (ELD) Yüksek Voltaj", "CL9 sigorta kutusundaki ELD sensörü arızası çok yaygındır."),
        "P1607" to DtcEntry("Motor (K24A3)", "ECM / PCM İç Devre Hatası (Honda)", "Ana röle, akü şase bağlantıları ve ECU beslemesi kontrol edilmelidir."),
        "P2101" to DtcEntry("Motor (K24A3)", "Elektronik Gaz Kelebeği (DBW) Motor Arızası", "Gaz kelebeği gövdesi sıkışması, kirlenme veya DBW rölesi."),
        "P2118" to DtcEntry("Motor (K24A3)", "Gaz Kelebeği Aktüatör Akım Aralığı", "ETCS/DBW sigortası ve gaz kelebeği motor soketini kontrol edin."),
        "P2122" to DtcEntry("Motor (K24A3)", "Gaz Pedalı Sensörü D (APP1) Düşük Voltaj", "Kaput içindeki CL9 gaz pedalı konum sensörü (APP) aşınması."),
        "P2123" to DtcEntry("Motor (K24A3)", "Gaz Pedalı Sensörü D (APP1) Yüksek Voltaj", "APP sensörü veya kablo tesisatı açık devre."),
        "P2127" to DtcEntry("Motor (K24A3)", "Gaz Pedalı Sensörü E (APP2) Düşük Voltaj", "APP sensörü yedek kanal voltajı düşük."),
        "P2128" to DtcEntry("Motor (K24A3)", "Gaz Pedalı Sensörü E (APP2) Yüksek Voltaj", "APP sensörü yedek kanal voltajı yüksek."),
        "P2135" to DtcEntry("Motor (K24A3)", "Gaz Kelebeği Konum Sensörü A/B Uyumsuzluğu", "DBW gövdesindeki çift TPS kanalı birbiriyle örtüşmüyor."),
        "P2138" to DtcEntry("Motor (K24A3)", "Gaz Pedalı Konum Sensörü (APP D/E) Uyumsuzluğu", "CL9'da kaput içindeki telli-elektronik APP sensörü aşınması kroniktir. Canlı APP D/E ile doğrulayın."),
        "P2176" to DtcEntry("Motor (K24A3)", "Gaz Kelebeği Rölanti Konumu Öğrenilmedi", "Akü sökülmesi veya kelebek temizliği sonrası rölanti adaptasyonu gerekir."),
        "P2183" to DtcEntry("Motor (K24A3)", "Radyatör Çıkış Sıcaklık Sensörü (ECT2) Performans", "Radyatör alt sensörü ile ECT1 arasındaki fark normal dışı."),
        "P2185" to DtcEntry("Motor (K24A3)", "Radyatör Çıkış Sıcaklık Sensörü (ECT2) Yüksek Voltaj", "Radyatör alt sensörü soketi veya kablo kopukluğu."),
        "P2646" to DtcEntry("Motor (K24A3)", "VTEC Yağ Basınç Şalteri Düşük Voltaj / Takılı", "Motor yağ seviyesi, VTEC solenoid süzgeç contası ve basınç şalterini kontrol edin."),
        "P2647" to DtcEntry("Motor (K24A3)", "VTEC Yağ Basınç Şalteri Yüksek Voltaj", "VTEC solenoid valfi veya basınç müşürü devresi."),
        "P2648" to DtcEntry("Motor (K24A3)", "VTEC Solenoid Kontrol Devresi Düşük", "VTEC solenoid soketi veya bobin kısa devresi."),
        "P2649" to DtcEntry("Motor (K24A3)", "VTEC Solenoid Kontrol Devresi Yüksek", "VTEC solenoid soketi çıkmış veya bobin açık devre."),

        // === OTOMATİK ŞANZIMAN (5AT MCTA) ===
        "P0700" to DtcEntry("Şanzıman (MCTA 5AT)", "Otomatik Şanzıman Kontrol Sistemi Arıza İsteği", "Genel şanzıman uyarı kodudur; beraberindeki P07xx/P08xx/P17xx koduna bakın."),
        "P0705" to DtcEntry("Şanzıman (MCTA 5AT)", "Vites Seçici Konum Sensörü (TR Switch) Arızası", "Şanzıman üzerindeki PRNDL konum şalteri nemlenmesi/aşınması (CL9'da yaygındır)."),
        "P0715" to DtcEntry("Şanzıman (MCTA 5AT)", "Giriş / Türbin Hız Sensörü Devresi", "Şanzıman ana mil hız sensörü veya kablo soketi."),
        "P0717" to DtcEntry("Şanzıman (MCTA 5AT)", "Giriş / Türbin Hız Sensörü Sinyal Yok", "Ana mil hız sensörü okuma yapmıyor."),
        "P0720" to DtcEntry("Şanzıman (MCTA 5AT)", "Çıkış Mili Hız Sensörü Devresi", "Şanzıman çıkış hız sensörü (countershaft) kontrolü."),
        "P0722" to DtcEntry("Şanzıman (MCTA 5AT)", "Çıkış Mili Hız Sensörü Sinyal Yok", "Çıkış hız sensörü kopuk veya arızalı."),
        "P0730" to DtcEntry("Şanzıman (MCTA 5AT)", "Hatalı Vites Oranı / Kavrama Kayması", "Honda DW-1 ATF seviyesi/durumu, harici ATF filtresi ve kavrama basıncı kontrolü gerekir."),
        "P0740" to DtcEntry("Şanzıman (MCTA 5AT)", "Tork Konvertörü Kilitleme (TCC) Devresi", "Lock-up solenoidi, tıkalı harici ATF filtresi veya tork konvertörü."),
        "P0741" to DtcEntry("Şanzıman (MCTA 5AT)", "Tork Konvertörü Kilitleme (TCC) Performans", "Otoyol hızında tork konvertörü tam kilitlenemiyor; DW-1 yağ ve solenoid kontrolü."),
        "P0752" to DtcEntry("Şanzıman (MCTA 5AT)", "Vites Solenoidi A Açık Takılı Kaldı", "MCTA vites solenoidi A mekanik takılma veya kirli ATF."),
        "P0753" to DtcEntry("Şanzıman (MCTA 5AT)", "Vites Solenoidi A Elektrik Arızası", "MCTA vites solenoidi A bobin direnci ve tesisatı."),
        "P0757" to DtcEntry("Şanzıman (MCTA 5AT)", "Vites Solenoidi B Açık Takılı Kaldı", "MCTA vites solenoidi B mekanik takılma."),
        "P0758" to DtcEntry("Şanzıman (MCTA 5AT)", "Vites Solenoidi B Elektrik Arızası", "MCTA vites solenoidi B bobin direnci ve tesisatı."),
        "P0776" to DtcEntry("Şanzıman (MCTA 5AT)", "Basınç Kontrol Solenoidi B Performans/Takılı", "Lineer basınç solenoidi temizliği ve DW-1 yağ değişimi önerilir."),
        "P0780" to DtcEntry("Şanzıman (MCTA 5AT)", "Vites Geçiş Arızası", "Vites geçişlerinde gecikme/vuruntu; basınç şalterleri ve ATF seviyesi kontrolü."),
        "P0845" to DtcEntry("Şanzıman (MCTA 5AT)", "3. Vites Şanzıman Yağ Basınç Şalteri", "CL9 MCTA şanzımanda 3. vites basınç müşürü çok sık görülür (ekonomik parça)."),
        "P0847" to DtcEntry("Şanzıman (MCTA 5AT)", "3. Vites Basınç Şalteri Düşük Voltaj", "3. vites basınç müşürü kısa devre veya arızalı müşür."),
        "P0848" to DtcEntry("Şanzıman (MCTA 5AT)", "3. Vites Basınç Şalteri Yüksek Voltaj", "3. vites basınç müşürü soketi kopuk veya arızalı."),
        "P0872" to DtcEntry("Şanzıman (MCTA 5AT)", "2. / 4. Vites Basınç Şalteri Düşük Voltaj", "Şanzıman basınç müşürü kısa devre veya arıza."),
        "P0873" to DtcEntry("Şanzıman (MCTA 5AT)", "2. / 4. Vites Basınç Şalteri Yüksek Voltaj", "Şanzıman basınç müşürü açık devre."),
        "P0962" to DtcEntry("Şanzıman (MCTA 5AT)", "Basınç Kontrol Solenoidi A Düşük Devre", "Lineer solenoid A soket ve bobin direnci kontrolü."),
        "P0963" to DtcEntry("Şanzıman (MCTA 5AT)", "Basınç Kontrol Solenoidi A Yüksek Devre", "Lineer solenoid A açık devre kontrolü."),
        "P1738" to DtcEntry("Şanzıman (MCTA 5AT)", "2. Kavrama Basınç Şalteri Arızası", "MCTA 2. kavrama basınç müşürü kontrolü."),
        "P1739" to DtcEntry("Şanzıman (MCTA 5AT)", "3. Kavrama Basınç Şalteri Arızası", "MCTA 3. kavrama basınç müşürü kontrolü."),
        "P1753" to DtcEntry("Şanzıman (MCTA 5AT)", "Tork Konvertörü Kavrama Solenoidi A Arızası", "Lock-up solenoidi A elektrik/mekanik kontrolü."),
        "P1768" to DtcEntry("Şanzıman (MCTA 5AT)", "Lineer Kavrama Basınç Kontrol Solenoidi A", "Çiftli lineer solenoid temizliği/değişimi ve Honda DW-1 yağ değişimi önerilir."),
        "P1773" to DtcEntry("Şanzıman (MCTA 5AT)", "Lineer Kavrama Basınç Kontrol Solenoidi B", "Lineer solenoid B bobin ve süzgeç kontrolü.")
    )

    fun lookup(code: String, isPending: Boolean): DtcCode {
        val norm = code.uppercase(Locale.US)
        val entry = db[norm]
        if (entry != null) {
            return DtcCode(norm, isPending, entry.system, entry.desc, entry.note)
        }
        // Akıllı SAE J2012 / Honda Alt Sistem Çözümleyici (Hiçbir kod açıklamasız kalmaz)
        val (sys, desc, note) = decodeSubsystemFallback(norm)
        return DtcCode(norm, isPending, sys, desc, note)
    }

    private fun decodeSubsystemFallback(code: String): Triple<String, String, String> {
        if (code.length < 5) {
            return Triple("Motor (K24A3)", "OBD-II Tanı Kodu ($code)", "Bağlantı ve sensör soketlerini kontrol edip tekrar tarayın.")
        }
        val isTrans = code.startsWith("P07") || code.startsWith("P08") || code.startsWith("P09") || code.startsWith("P17") || code.startsWith("P18")
        if (isTrans) {
            return Triple(
                "Şanzıman (MCTA 5AT)",
                "5AT Otomatik Şanzıman Devre/Basınç Arızası ($code)",
                "Honda DW-1 ATF seviyesi, şanzıman basınç şalterleri ve lineer solenoid soketleri kontrol edilmelidir."
            )
        }
        return when {
            code.startsWith("P01") || code.startsWith("P11") || code.startsWith("P22") -> Triple(
                "Motor (K24A3)",
                "Yakıt / Hava Ölçümü ve Oksijen (A/F) Sensörü Arızası ($code)",
                "Ön geniş bant A/F sensörü (B1S1), MAP, IAT, vakum hortumları ve LPG karışım ayarını kontrol edin."
            )
            code.startsWith("P02") || code.startsWith("P12") -> Triple(
                "Motor (K24A3)",
                "Yakıt Enjeksiyonu / Hava-Yakıt veya VTEC Devre Arızası ($code)",
                "Enjektör soketleri, LPG kesici bağlantıları, yakıt basıncı ve VTEC solenoid hattını kontrol edin."
            )
            code.startsWith("P03") || code.startsWith("P13") -> Triple(
                "Motor (K24A3)",
                "Ateşleme Sistemi, Tekleme veya Krank/Eksantrik Sensörü ($code)",
                "İridyum bujiler, ateşleme bobinleri, vuruntu/CKP/CMP sensörleri ve sübap ayarını kontrol edin."
            )
            code.startsWith("P04") || code.startsWith("P14") -> Triple(
                "Motor (K24A3)",
                "Emisyon, Katalizör, EGR veya EVAP Buhar Sistemi ($code)",
                "EGR kanalları, yakıt depo kapağı, kanister valfi ve katalizör sonrası O2 sensörünü kontrol edin."
            )
            code.startsWith("P05") || code.startsWith("P15") -> Triple(
                "Motor (K24A3)",
                "Hız Sinyali, Rölanti Kontrolü veya Şarj/Voltaj Sistemi ($code)",
                "Akü/alternatör voltajı, gaz kelebeği rölanti adaptasyonu ve hız sensörü hattını kontrol edin."
            )
            code.startsWith("P06") || code.startsWith("P16") -> Triple(
                "Motor (K24A3)",
                "Motor Beyni (ECM/PCM) veya İletişim Devresi ($code)",
                "Akü şase bağlantıları, ana röle ve ECU soket oksitlenmesini kontrol edin."
            )
            code.startsWith("P21") -> Triple(
                "Motor (K24A3)",
                "Elektronik Gaz Kelebeği (DBW) / Gaz Pedalı (APP) Sistemi ($code)",
                "Kaput içi APP gaz pedalı sensörü ve DBW gaz kelebeği soketlerini kontrol edin."
            )
            code.startsWith("P26") -> Triple(
                "Motor (K24A3)",
                "i-VTEC Solenoid / Yağ Basınç Kontrol Devresi ($code)",
                "Motor yağ seviyesi, VTEC süzgeç contası ve basınç müşürü soketini kontrol edin."
            )
            code.startsWith("U") -> Triple(
                "Ağ / İletişim",
                "Modüller Arası Veri Hattı İletişim Hatası ($code)",
                "Akü voltaj düşüklüğü veya gevşek OBD-II / modül soketinden kaynaklanabilir."
            )
            else -> Triple(
                "Motor (K24A3)",
                "Honda CL9 K24A3 Özel Arıza Kodu ($code)",
                "Kodu kaydettikten sonra canlı sensör değerleriyle birlikte yetkili Honda/OBD servisinde doğrulayın."
            )
        }
    }

    fun parseDtcResponse(raw: String, expectedHeader: String, isPending: Boolean): List<DtcCode> {
        val clean = raw.replace(" ", "").uppercase(Locale.US)
        if (clean.contains("NODATA") || !clean.contains(expectedHeader)) return emptyList()
        val idx = clean.indexOf(expectedHeader)
        val payload = clean.substring(idx + 2)
        val codes = mutableListOf<DtcCode>()
        var i = 0
        while (i + 3 < payload.length) {
            val pair = payload.substring(i, i + 4)
            if (pair != "0000" && pair.all { it in '0'..'9' || it in 'A'..'F' }) {
                val firstNibble = pair[0].digitToInt(16)
                val prefix = when (firstNibble shr 2) {
                    0 -> "P"
                    1 -> "C"
                    2 -> "B"
                    else -> "U"
                }
                val secondDigit = (firstNibble and 0x03).toString()
                val fullCode = prefix + secondDigit + pair.substring(1)
                if (codes.none { it.code == fullCode }) {
                    codes.add(lookup(fullCode, isPending))
                }
            }
            i += 4
        }
        return codes
    }
}
