package com.cl9tr.obd2.obd

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 2004 Honda Accord CL9 (K24A3 2.4 i-VTEC + 5AT MCTA) için
 * ISO 9141-2 K-Line hattına ek polleme yükü bindirmeden çalışan
 * Sanal Motor Yağ Sıcaklığı (VirtualEOT) ve Hibrit Şanzıman Yağ Sıcaklığı (ATFMonitor) modülleri.
 */
data class ThermalConfig(
    val coldStartDeltaMaxC: Double = 15.0,
    val warmStartEctMinC: Double = 60.0,
    val eotWarmStartFactor: Double = 0.92,
    val atfWarmStartFactor: Double = 0.85,
    val eotTauHeatSec: Double = 300.0,
    val eotTauCoolSec: Double = 450.0,
    val atfTauHeatSec: Double = 260.0,
    val atfTauCoolSec: Double = 380.0,
    val vtecRpmThreshold: Double = 6000.0,
    val gyroStrainWeightEotC: Double = 4.5,
    val gyroStrainWeightAtfC: Double = 5.5,
    val eotColdMaxC: Double = 75.0,
    val eotIdealMinC: Double = 85.0,
    val eotIdealMaxC: Double = 105.0,
    val eotHighMinC: Double = 115.0,
    val atfColdMaxC: Double = 50.0,
    val atfIdealMinC: Double = 70.0,
    val atfIdealMaxC: Double = 95.0,
    val atfHighMinC: Double = 110.0
)

enum class ThermalStatus(val labelTr: String) {
    COLD("Soğuk"),
    WARMING("Isınıyor"),
    IDEAL("İdeal"),
    WARM("Sıcak"),
    HIGH("Yüksek Sıcaklık Uyarısı")
}

data class ThermalSampleInput(
    val ectC: Double,
    val iatC: Double,
    val rpm: Double,
    val mapKpa: Double,
    val tpsPct: Double,
    val speedKmh: Double,
    val gyroStrainG: Double = 0.0,
    val dtSec: Double = 1.0
)

data class ThermalReading(
    val temperatureC: Double,
    val isEstimated: Boolean,
    val status: ThermalStatus,
    val adviceTr: String
)

/**
 * Aşama A (Gerçek Sensör Denemesi) için soyut Honda TCM/HDS ATF arayüzü.
 * ELM327 geçerli ATF sıcaklığı döndürürse gerçek veri kullanılır; aksi halde sanal modele geçilir.
 */
interface HondaTcmAtfProbe {
    fun probeAtfTempC(): Double?
}

class VirtualEOTEstimator(private val config: ThermalConfig = ThermalConfig()) {
    private var initialized = false
    private var currentEotC: Double = 20.0

    fun reset() {
        initialized = false
    }

    fun update(input: ThermalSampleInput): ThermalReading {
        if (!initialized) {
            currentEotC = when {
                (input.ectC - input.iatC) <= config.coldStartDeltaMaxC -> input.ectC
                input.ectC > config.warmStartEctMinC -> input.ectC * config.eotWarmStartFactor
                else -> input.ectC
            }
            initialized = true
        }

        var targetC = input.ectC
        if (input.mapKpa > 55.0) {
            targetC += ((input.mapKpa - 55.0) / 45.0) * 10.0
        }
        if (input.rpm > 3500.0) {
            targetC += ((input.rpm - 3500.0) / 3500.0) * 11.0
        }
        if (input.rpm >= config.vtecRpmThreshold && input.mapKpa >= 78.0) {
            targetC += 6.5
        }
        targetC += min(1.5, max(0.0, input.gyroStrainG)) * config.gyroStrainWeightEotC
        if (input.speedKmh > 70.0 && input.mapKpa < 62.0) {
            targetC -= min(6.0, (input.speedKmh - 70.0) * 0.09)
        }

        val tau = if (targetC >= currentEotC) config.eotTauHeatSec else config.eotTauCoolSec
        val dt = max(0.1, input.dtSec)
        currentEotC += ((targetC - currentEotC) / tau) * dt
        currentEotC = currentEotC.coerceIn(input.iatC, 140.0)

        val (status, advice) = when {
            currentEotC < config.eotColdMaxC -> ThermalStatus.COLD to "Yağ henüz soğuk; i-VTEC ve tam gaz önerilmez."
            currentEotC in config.eotIdealMinC..config.eotIdealMaxC -> ThermalStatus.IDEAL to "Motor yağı ideal çalışma sıcaklığında."
            currentEotC > config.eotHighMinC -> ThermalStatus.HIGH to "Motor yağı yüksek sıcaklıkta! Tempoyu düşürün."
            currentEotC < config.eotIdealMinC -> ThermalStatus.WARMING to "Motor yağı ideal bandına doğru ısınıyor."
            else -> ThermalStatus.WARM to "Motor yağı yüksek yük altında sıcak seyrediyor."
        }
        return ThermalReading(
            temperatureC = currentEotC,
            isEstimated = true,
            status = status,
            adviceTr = advice
        )
    }
}

class VirtualATFEstimator(private val config: ThermalConfig = ThermalConfig()) {
    private var initialized = false
    private var currentAtfC: Double = 20.0

    fun reset() {
        initialized = false
    }

    fun update(input: ThermalSampleInput): ThermalReading {
        if (!initialized) {
            currentAtfC = when {
                (input.ectC - input.iatC) <= config.coldStartDeltaMaxC -> input.ectC
                input.ectC > config.warmStartEctMinC -> input.ectC * config.atfWarmStartFactor
                else -> input.ectC
            }
            initialized = true
        }

        var targetC = input.ectC * 0.96
        val rpmSpeedRatio = if (input.speedKmh > 2.0) input.rpm / input.speedKmh else input.rpm / 12.0
        val isCitySlip = input.speedKmh < 40.0 && (input.mapKpa > 58.0 || rpmSpeedRatio > 58.0)
        val isHighwayLockup = input.speedKmh > 70.0 && rpmSpeedRatio < 34.0

        if (isCitySlip) {
            targetC += 13.0 + min(14.0, max(0.0, (input.mapKpa - 50.0) * 0.25))
        }
        targetC += min(1.5, max(0.0, input.gyroStrainG)) * config.gyroStrainWeightAtfC

        if (isHighwayLockup) {
            targetC = (input.ectC * 0.94) - min(5.0, (input.speedKmh - 70.0) * 0.06)
        }

        val tau = if (targetC >= currentAtfC) config.atfTauHeatSec else config.atfTauCoolSec
        val dt = max(0.1, input.dtSec)
        currentAtfC += ((targetC - currentAtfC) / tau) * dt
        currentAtfC = currentAtfC.coerceIn(input.iatC, 135.0)

        val (status, advice) = when {
            currentAtfC < config.atfColdMaxC -> ThermalStatus.COLD to "Şanzıman yağı soğuk; sert kalkışlardan kaçının."
            currentAtfC in config.atfIdealMinC..config.atfIdealMaxC -> ThermalStatus.IDEAL to "5AT şanzıman yağı ideal çalışma sıcaklığında."
            currentAtfC > config.atfHighMinC -> ThermalStatus.HIGH to "ATF aşırı ısınma uyarısı! Dur-kalk/yokuş yükünü azaltın."
            currentAtfC < config.atfIdealMinC -> ThermalStatus.WARMING to "Şanzıman yağı ısınıyor."
            else -> ThermalStatus.WARM to "Şanzıman yağı sıcak; mümkünse akıcı sürüşle soğutun."
        }
        return ThermalReading(
            temperatureC = currentAtfC,
            isEstimated = true,
            status = status,
            adviceTr = advice
        )
    }
}

class ATFMonitor(
    private val probe: HondaTcmAtfProbe? = null,
    private val config: ThermalConfig = ThermalConfig()
) {
    private val virtualEstimator = VirtualATFEstimator(config)
    private var probedOnce = false
    private var realSensorSupported = false

    fun reset() {
        probedOnce = false
        realSensorSupported = false
        virtualEstimator.reset()
    }

    fun update(input: ThermalSampleInput): ThermalReading {
        if (!probedOnce) {
            probedOnce = true
            val firstReal = probe?.probeAtfTempC()
            if (firstReal != null && firstReal in -20.0..150.0) {
                realSensorSupported = true
                return toRealReading(firstReal)
            }
        } else if (realSensorSupported) {
            val realVal = probe?.probeAtfTempC()
            if (realVal != null && realVal in -20.0..150.0) {
                return toRealReading(realVal)
            } else {
                realSensorSupported = false
            }
        }
        return virtualEstimator.update(input)
    }

    private fun toRealReading(tempC: Double): ThermalReading {
        val status = when {
            tempC < config.atfColdMaxC -> ThermalStatus.COLD
            tempC in config.atfIdealMinC..config.atfIdealMaxC -> ThermalStatus.IDEAL
            tempC > config.atfHighMinC -> ThermalStatus.HIGH
            tempC < config.atfIdealMinC -> ThermalStatus.WARMING
            else -> ThermalStatus.WARM
        }
        return ThermalReading(
            temperatureC = tempC,
            isEstimated = false,
            status = status,
            adviceTr = "Honda TCM gerçek sensör verisi okunuyor."
        )
    }
}
