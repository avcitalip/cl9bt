package com.cl9tr.obd2

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cl9tr.obd2.model.AdapterTier
import com.cl9tr.obd2.model.ConnectionPhase
import com.cl9tr.obd2.model.VehicleProfile
import com.cl9tr.obd2.ui.screens.*
import com.cl9tr.obd2.ui.theme.*
import com.cl9tr.obd2.obd.Cl9BackgroundService
import com.cl9tr.obd2.viewmodel.ObdViewModel

class MainActivity : ComponentActivity() {

    private var onPermissionResultCallback: (() -> Unit)? = null
    var onSystemBackHandler: (() -> Boolean)? = null
    val confirmExitFromNotif = mutableStateOf(false)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(Cl9BackgroundService.EXTRA_CONFIRM_EXIT, false)) {
            confirmExitFromNotif.value = true
        }
    }
    private var locationManager: LocationManager? = null
    private var gpsListener: LocationListener? = null

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        onPermissionResultCallback?.invoke()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val permList = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permList.add(Manifest.permission.BLUETOOTH_CONNECT)
            permList.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permList.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permLauncher.launch(permList.toTypedArray())

        if (intent?.getBooleanExtra(Cl9BackgroundService.EXTRA_CONFIRM_EXIT, false) == true) {
            confirmExitFromNotif.value = true
        }

        // Kesin Sistem Geri Tuşu Yakalayıcısı: Önce önceki menüye döner, ana ekrandaysa arka plana alır
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val consumed = onSystemBackHandler?.invoke() ?: false
                if (!consumed) {
                    moveTaskToBack(true)
                }
            }
        })

        setContent {
            Cl9ObdTheme {
                val vm: ObdViewModel = viewModel()
                LaunchedEffect(Unit) {
                    vm.attachContext(this@MainActivity)
                    onPermissionResultCallback = {
                        vm.refreshPairedDevices()
                        startGpsAltitudeTracking(vm)
                    }
                    vm.refreshPairedDevices()
                    startGpsAltitudeTracking(vm)
                }
                val showExitConfirm by confirmExitFromNotif
                Cl9AppRoot(
                    vm = vm,
                    showExitConfirm = showExitConfirm,
                    onDismissExitConfirm = { confirmExitFromNotif.value = false },
                    onConfirmFullExit = {
                        confirmExitFromNotif.value = false
                        vm.disconnect()
                        Cl9BackgroundService.stop(this@MainActivity)
                        finishAndRemoveTask()
                    },
                    registerBackHandler = { handler -> onSystemBackHandler = handler }
                )
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startGpsAltitudeTracking(vm: ObdViewModel) {
        try {
            if (locationManager == null) {
                locationManager = getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            }
            if (gpsListener == null) {
                gpsListener = LocationListener { loc: Location ->
                    if (loc.hasAltitude()) vm.onGpsAltitudeUpdate(loc.altitude)
                }
                locationManager?.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    5000L,
                    25f,
                    gpsListener!!
                )
            }
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            gpsListener?.let { locationManager?.removeUpdates(it) }
        } catch (_: Exception) {}
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Cl9AppRoot(
    vm: ObdViewModel,
    showExitConfirm: Boolean = false,
    onDismissExitConfirm: () -> Unit = {},
    onConfirmFullExit: () -> Unit = {},
    registerBackHandler: ((() -> Boolean) -> Unit) = {}
) {
    val ctx = LocalContext.current
    val routeStack = remember { mutableStateListOf("home") }
    val currentRoute = routeStack.lastOrNull() ?: "home"
    fun navigateTo(route: String) {
        if (route == "home") { routeStack.clear(); routeStack.add("home") }
        else if (routeStack.lastOrNull() != route) { routeStack.add(route) }
    }
    fun popBack() {
        if (routeStack.size > 1) routeStack.removeAt(routeStack.lastIndex)
    }
    var showWelcome by remember { mutableStateOf(true) }
    var reorderMode by remember { mutableStateOf(false) }
    var showProfileSwitcher by remember { mutableStateOf(false) }
    var editingProfile by remember { mutableStateOf<VehicleProfile?>(null) }
    var showProfileEditor by remember { mutableStateOf(false) }

    val conn by vm.connectionState.collectAsState()
    val devices by vm.pairedDevices.collectAsState()
    val liveValues by vm.liveValues.collectAsState()
    val pinnedPids by vm.pinnedPids.collectAsState()
    val dtcs by vm.dtcs.collectAsState()
    val freeze by vm.freezeFrame.collectAsState()
    val readiness by vm.readiness.collectAsState()
    val ecu by vm.ecuIdentity.collectAsState()
    val isRec by vm.isRecordingCsv.collectAsState()
    val csvRows by vm.csvRows.collectAsState()
    val profiles by vm.profiles.collectAsState()
    val activeProfile by vm.activeProfile.collectAsState()
    val needsInitialProfile by vm.needsInitialProfile.collectAsState()
    val banner by vm.homeBanner.collectAsState()
    val perf by vm.perfMetrics.collectAsState()
    val fuel by vm.fuelMetrics.collectAsState()
    val simScenario by vm.simScenario.collectAsState()
    val trackedKm by vm.trackedKm.collectAsState()
    val trackedHours by vm.trackedHours.collectAsState()
    val menuOrder by vm.menuOrder.collectAsState()
    val customNames by vm.customNames.collectAsState()

    val isConnected = conn.phase == ConnectionPhase.CONNECTED || conn.phase == ConnectionPhase.DEMO_MODE
    val signalColor = when {
        !isConnected -> Color(0xFF64748B)
        conn.adapterTier == AdapterTier.TIER_1_PIC18F25K80 -> AccentGreen
        conn.adapterTier == AdapterTier.TIER_2_CLONE_V15 -> AccentAmber
        else -> AccentRed
    }

    val ctxLocal = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(isConnected) {
        if (isConnected) Cl9BackgroundService.start(ctxLocal)
    }

    if (showExitConfirm) {
        AlertDialog(
            onDismissRequest = onDismissExitConfirm,
            containerColor = CardSlate,
            title = { Text("Uygulamayı Sonlandır", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("CL9 arka planda çalışmayı durduracak ve OBD-II bağlantısı kapatılacak. Emin misiniz?", color = TextSecondary, fontSize = 13.sp) },
            confirmButton = {
                Button(
                    onClick = onConfirmFullExit,
                    colors = ButtonDefaults.buttonColors(containerColor = AccentRed)
                ) { Text("Evet, Sonlandır", color = Color.White, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = onDismissExitConfirm) { Text("Hayır", color = AccentCyan, fontWeight = FontWeight.Bold) }
            }
        )
    }

    val screenTitle = when (currentRoute) {
        "ai_chat" -> "CL9 Yapay Zeka Asistanı" 
        "home" -> "CL9"
        "dashboard" -> "Canlı Gösterge Paneli"
        "performance" -> "Hesaplanan Motor Performansı"
        "fuel" -> "Yakıt Tüketimi Yorumlaması"
        "sensors" -> "Tüm Sensörler"
        "dtc" -> "Arıza Kodları"
        "maintenance" -> "Muhtemel Arızalar ve Bakım"
        "connect" -> "Adaptör ve Protokol Analizi"
        "logger" -> "Sürüş Veri Kaydı"
        "advice" -> "Test ve Bilgilendirme"
        else -> "CL9"
    }

    LaunchedEffect(showProfileEditor, showProfileSwitcher, reorderMode, routeStack.size) {
        registerBackHandler {
            when {
                showProfileEditor && !needsInitialProfile -> { showProfileEditor = false; editingProfile = null; true }
                showProfileSwitcher -> { showProfileSwitcher = false; true }
                reorderMode -> { reorderMode = false; true }
                routeStack.size > 1 -> { popBack(); true }
                else -> false
            }
        }
    }

    // Sistem geri tuşu tek merkezden MainActivity.onBackPressedDispatcher ile yönetilir

    if (showWelcome) {
        Box(modifier = Modifier.fillMaxSize().background(BgObsidian)) {
            Image(
                painter = painterResource(id = R.drawable.k24a3_welcome_bg),
                contentDescription = "K24A3 Motor",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        0.0f to Color(0xD9000000),
                        0.32f to Color(0x22000000),
                        0.62f to Color(0x22000000),
                        0.86f to Color(0xEB000000),
                        1.0f to Color(0xFA000000)
                    )
                )
            )
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 40.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("HOŞ GELDİNİZ", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        "Türkiye'de satılan Honda Accord 7. Nesil (CL9) K24A3 2.4 i-VTEC otomatik vites araçlar için özelleştirilmiş ELM327 Mini OBD-II arıza tespit ve sürüş bilgi yazılımı.",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontStyle = FontStyle.Italic,
                        lineHeight = 19.sp,
                        textAlign = TextAlign.Center
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Her şeyin sadece... tıkır tıkır işlemesi ne güzel, değil mi?",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontStyle = FontStyle.Italic,
                        textAlign = TextAlign.Center
                    )
                    Button(
                        onClick = { showWelcome = false },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = BgObsidian)
                    ) {
                        Text("HEMEN KULLANMAYA BAŞLA", fontSize = 14.5.sp, fontWeight = FontWeight.Black)
                    }
                    Text("Yapımcı: Talip Avcı by Gemini", color = TextSecondary, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                    OutlinedButton(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_SENDTO).apply {
                                    data = Uri.parse("mailto:avcitalip@gmail.com")
                                    putExtra(Intent.EXTRA_SUBJECT, "CL9 OBD-II Uygulaması İletişim")
                                }
                                ctx.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Email, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("İletişim için E-Posta Gönder", color = AccentCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        return
    }

    if (needsInitialProfile || showProfileEditor) {
        ProfileSetupDialog(
            initial = editingProfile,
            canClose = !needsInitialProfile,
            onDismiss = { showProfileEditor = false; editingProfile = null },
            onSave = { p ->
                vm.saveProfile(p)
                showProfileEditor = false
                editingProfile = null
            },
            onStartSimulation = {
                showProfileEditor = false
                editingProfile = null
                vm.startDemoMode(AdapterTier.TIER_1_PIC18F25K80)
            }
        )
    }

    if (showProfileSwitcher) {
        ProfileSwitcherDialog(
            profiles = profiles.ifEmpty { listOf(activeProfile) },
            activeId = activeProfile.id,
            onDismiss = { showProfileSwitcher = false },
            onSelect = { id -> vm.selectProfile(id); showProfileSwitcher = false },
            onEdit = { p -> editingProfile = p; showProfileSwitcher = false; showProfileEditor = true },
            onDelete = { id -> vm.deleteProfile(id) },
            onAddNew = { editingProfile = null; showProfileSwitcher = false; showProfileEditor = true }
        )
    }

    Scaffold(
        containerColor = BgObsidian,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BgShell,
                    titleContentColor = TextPrimary
                ),
                title = {
                    Text(
                        text = screenTitle,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    if (currentRoute != "home") {
                        IconButton(onClick = { popBack(); reorderMode = false }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri", tint = TextPrimary)
                        }
                    } else {
                        IconButton(onClick = { reorderMode = !reorderMode }) {
                            Icon(
                                Icons.Default.FormatListNumbered,
                                contentDescription = "Sırala",
                                tint = if (reorderMode) AccentCyan else TextSecondary
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { showProfileSwitcher = true }) {
                        Icon(Icons.Default.DirectionsCar, contentDescription = "Profil", tint = AccentCyan)
                    }
                    IconButton(onClick = { vm.refreshPairedDevices(); navigateTo("connect"); reorderMode = false }) {
                        Icon(Icons.Default.SignalCellularAlt, contentDescription = "OBD Sinyal", tint = signalColor)
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = BgShell, tonalElevation = 0.dp) {
                val tabs = listOf(
                    Triple("dashboard", "Canlı Veri", Icons.Default.Speed),
                    Triple("home", "Ana Ekran", Icons.Default.Home),
                    Triple("ai_chat", "Yapay Zeka", Icons.Default.AutoAwesome)
                )
                tabs.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = currentRoute == route,
                        onClick = { navigateTo(route); reorderMode = false },
                        icon = { Icon(icon, contentDescription = label, modifier = Modifier.size(20.dp)) },
                        label = { Text(label, fontSize = 10.5.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AccentCyan,
                            selectedTextColor = AccentCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = AccentCyan.copy(alpha = 0.14f)
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(modifier = Modifier.fillMaxSize().padding(pad)) {
            when (currentRoute) {
                "ai_chat" -> Cl9AiChatScreen(
                    profile = activeProfile,
                    liveValues = liveValues,
                    dtcs = dtcs
                )
                "home" -> HomeScreen(
                    conn = conn,
                    profile = activeProfile,
                    banner = banner,
                    dtcCount = dtcs.size,
                    liveRpm = liveValues["010C"]?.let { "${it.formattedValue} d/dk" } ?: "-- d/dk",
                    menuOrder = menuOrder,
                    reorderMode = reorderMode,
                    onMoveItem = vm::moveMenuItem,
                    onNavigate = {
                        if (it == "connect") vm.refreshPairedDevices()
                        if (it == "advice") { vm.readFreezeFrame(); vm.readEmissionsAndMode06(); vm.readEcuIdentity() }
                        navigateTo(it)
                        reorderMode = false
                    },
                    onOpenProfileSwitcher = { showProfileSwitcher = true },
                    onToggleSim = {
                        if (isConnected) vm.disconnect()
                        else vm.startDemoMode(AdapterTier.TIER_1_PIC18F25K80)
                    },
                    onTestMeteoAlert = {
                        vm.triggerMeteorologicalHazard("AFAD ve Meteoroloji Uyarısı: Bölgenizde ani buzlanma ve gizli don tehlikesi mevcuttur. Hızınızı düşürün ve ani fren yapmayın.")
                    }
                )
                "dashboard" -> DashboardScreen(
                    conn = conn,
                    fuel = fuel,
                    liveValues = liveValues,
                    pinnedPids = pinnedPids,
                    customNames = customNames,
                    simScenario = simScenario,
                    onSelectScenario = vm::setSimScenario,
                    onStartSim = { vm.startDemoMode(AdapterTier.TIER_1_PIC18F25K80) }
                )
                "performance" -> PerformanceScreen(
                    metrics = perf,
                    trackedKm = trackedKm,
                    trackedHours = trackedHours,
                    onStartSim = { vm.startDemoMode(AdapterTier.TIER_1_PIC18F25K80) }
                )
                "fuel" -> FuelAnalysisScreen(
                    fuel = fuel,
                    onStartSim = { vm.startDemoMode(AdapterTier.TIER_1_PIC18F25K80) }
                )
                "sensors" -> AllSensorsScreen(liveValues, pinnedPids, vm::togglePinnedPid)
                "dtc" -> DtcScreen(dtcs, vm::readDtcs, vm::clearDtcs)
                "maintenance" -> MaintenanceScreen(trackedKm, trackedHours, activeProfile, vm::resetDriveData)
                "connect" -> AdapterConnectScreen(
                    conn = conn,
                    pairedDevices = devices,
                    onRefreshDevices = vm::refreshPairedDevices,
                    onSelectDevice = vm::connectToDevice,
                    onStartDemo = vm::startDemoMode,
                    onDisconnect = vm::disconnect
                )
                "logger" -> CsvLoggerScreen(
                    isRecording = isRec,
                    rows = csvRows,
                    onToggle = vm::toggleCsvRecording,
                    onClear = vm::clearCsvLogs,
                    onShare = { vm.saveAndShareCsv(ctx) }
                )
                "advice" -> TestAndInfoScreen(
                    conn = conn,
                    profile = activeProfile,
                    readiness = readiness,
                    freeze = freeze,
                    ecu = ecu,
                    trackedKm = trackedKm,
                    trackedHours = trackedHours,
                    onNavigate = { target -> navigateTo(target) }
                )
            }
        }
    }
}


@Composable
fun Cl9AiChatScreen(
    profile: com.cl9tr.obd2.model.VehicleProfile,
    liveValues: Map<String, com.cl9tr.obd2.model.LivePidValue>,
    dtcs: List<com.cl9tr.obd2.model.DtcCode>
) {
    var input by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            false to "Merhaba! Ben 2004 Honda Accord CL9 (K24A3 2.4 i-VTEC 5AT) Yapay Zeka Asistanın. Aracın, arıza kodları (P1157, P0219 vb.), LPG ayarı, yağ/ATF bakımı veya canlı sensör değerlerin hakkında istediğini sorabilirsin."
        )
    }

    fun answerQuestion(q: String): String {
        val t = q.lowercase()
        val rpm = liveValues["010C"]?.formattedValue ?: "--"
        val ect = liveValues["0105"]?.formattedValue ?: "--"
        val ltft = liveValues["0107"]?.formattedValue ?: "--"
        return when {
            t.contains("p1157") || t.contains("oksijen") || t.contains("a/f") ->
                "P1157, 2004 CL9 K24A3'te ön geniş bant A/F (B1S1) sensörü devre yüksek voltaj arızasıdır. Orijinal Denso 234-9040 sensör, soket oksitlenmesi ve motor içi LAF rölesini kontrol etmelisin."
            t.contains("p0219") || t.contains("aşırı devir") ->
                "P0219, motorun izin verilen maksimum devir sınırını aştığını gösterir (genellikle triptronik sert vites küçültmede oluşur). Motor sesini ve zincir gergisini dinleyip kodu temizleyebilirsin."
            t.contains("lpg") || t.contains("yakıt") || t.contains("stft") || t.contains("ltft") ->
                "K24A3 LPG'de ideal stokiyometri 15.5:1'dir. Canlı LTFT değerin: $ltft%. ±%5 içinde kalması, her 40.000 km'de bir sübap ayarı yapılması motor sağlığı için kritiktir."
            t.contains("şanzıman") || t.contains("atf") || t.contains("vites") ->
                "CL9 5AT (MCTA) şanzımanda mutlaka yalnızca orijinal Honda ATF DW-1 kullanılmalı, 40.000 km'de bir 3 litre boşalt-doldur ve harici ATF filtresi değişimi yapılmalıdır."
            t.contains("yağ") || t.contains("bakım") ->
                "K24A3 için tam sentetik 5W-30 (API SP / ILSAC GF-6) yağ ve 8.000–10.000 km değişim aralığı idealdir. Yağ sıcaklığı 75 °C'yi geçmeden i-VTEC yüksek devir önerilmez."
            t.contains("vtec") ->
                "Orijinal yazılımda K24A3 i-VTEC 6000 d/dk'da, Stage 1 yazılımda 5100 d/dk'da, agresif yazılımda 4600 d/dk'da açar."
            else ->
                "Aracının mevcut verileri (${profile.plate}, ${profile.fuel}): Devir $rpm d/dk, Hararet $ect °C, LTFT $ltft%, aktif arıza kodu sayısı: ${dtcs.size}. Belirli bir arıza kodu (örn: P1157), LPG ayarı, şanzıman veya bakım sorusu sorabilirsin."
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages.size) { idx ->
                val (isUser, text) = messages[idx]
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        color = if (isUser) AccentCyan.copy(alpha = 0.2f) else CardSlate,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, if (isUser) AccentCyan.copy(alpha = 0.5f) else Color(0xFF2A3444))
                    ) {
                        Text(text, color = TextPrimary, fontSize = 12.5.sp, modifier = Modifier.padding(11.dp))
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("CL9 hakkında sor...", fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            Button(
                onClick = {
                    val q = input.trim()
                    if (q.isNotEmpty()) {
                        messages.add(true to q)
                        messages.add(false to answerQuestion(q))
                        input = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentCyan)
            ) {
                Text("Sor", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
