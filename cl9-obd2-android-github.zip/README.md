# CL9 OBD-II — GitHub Actions ile Otomatik Android APK Oluşturma

Bu paket, **Honda Accord 7. Nesil (CL9) K24A3** uygulamanızı hiçbir bilgisayar kurulumu yapmadan doğrudan **GitHub Actions** üzerinden kurulabilir Android **`.apk`** dosyasına çevirmeniz için hazırlanmıştır.

## Adım Adım APK Oluşturma (3 Dakika)

1. Bu ZIP dosyasını bilgisayarınızda bir klasöre çıkartın.
2. [GitHub](https://github.com/new) üzerinden yeni bir depo (Repository) oluşturun (Public veya Private olabilir).
3. Çıkardığınız tüm dosyaları (`.github` klasörü dahil!) bu depoya yükleyin (**Add file → Upload files** veya `git push`).
4. Depo sayfasında üst menüden **Actions** sekmesine tıklayın.
5. **Build CL9 Android APK** iş akışı otomatik başlar (başlamazsa sağdan **Run workflow** butonuna basın).
6. İşlem yaklaşık 2–4 dakika içinde yeşil tik (`✓`) ile tamamlandığında, ilgili çalışmaya tıklayıp en alttaki **Artifacts** bölümünden **`CL9-OBD2-APK`** dosyasını indirin.
7. İndirilen ZIP içindeki `app-debug.apk` dosyasını Android telefonunuza aktarıp kurun.

## Paket İçeriği
- `www/index.html` — Test edilmiş ve hataları giderilmiş güncel CL9 uygulaması
- `capacitor.config.json` & `package.json` — Capacitor 6 Android yapılandırması
- `scripts/patch-android.mjs` — Bluetooth (OBD-II), GPS, Ekranı Açık Tutma ve Android Auto izin betiği
- `.github/workflows/build-apk.yml` — GitHub Actions otomatik APK derleme hattı
