import fs from "node:fs";
import path from "node:path";

const androidDir = path.resolve("android");
const manifestPath = path.join(androidDir, "app", "src", "main", "AndroidManifest.xml");
const xmlDir = path.join(androidDir, "app", "src", "main", "res", "xml");
const mainActivityPath = path.join(
  androidDir, "app", "src", "main", "java", "com", "talipavci", "cl9obd2", "MainActivity.java"
);

if (!fs.existsSync(manifestPath)) {
  console.error("AndroidManifest.xml bulunamadı. Önce 'npx cap add android' çalıştırın.");
  process.exit(1);
}

// 1. Android Auto descriptor XML
fs.mkdirSync(xmlDir, { recursive: true });
fs.writeFileSync(
  path.join(xmlDir, "automotive_app_desc.xml"),
  `<?xml version="1.0" encoding="utf-8"?>\n<automotiveApp>\n    <uses name="template"/>\n</automotiveApp>\n`,
  "utf8"
);

// 2. Patch AndroidManifest.xml with OBD-II Bluetooth, GPS, WakeLock & Android Auto metadata
let manifest = fs.readFileSync(manifestPath, "utf8");
const permissions = [
  '<uses-permission android:name="android.permission.INTERNET" />',
  '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />',
  '<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />',
  '<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />',
  '<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />',
  '<uses-permission android:name="android.permission.BLUETOOTH_SCAN" />',
  '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
  '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
  '<uses-permission android:name="android.permission.WAKE_LOCK" />'
];

const missingPerms = permissions.filter(p => !manifest.includes(p.split('"')[1]));
if (missingPerms.length > 0) {
  manifest = manifest.replace(
    "<application",
    missingPerms.join("\n    ") + "\n\n    <application"
  );
}

if (!manifest.includes("com.google.android.gms.car.application")) {
  manifest = manifest.replace(
    "</application>",
    `        <meta-data\n            android:name="com.google.android.gms.car.application"\n            android:resource="@xml/automotive_app_desc" />\n    </application>`
  );
}

if (!manifest.includes("android:screenOrientation")) {
  manifest = manifest.replace(
    "<activity",
    '<activity\n            android:screenOrientation="fullSensor"'
  );
}

fs.writeFileSync(manifestPath, manifest, "utf8");

// 3. Keep screen awake & dark system bars in MainActivity.java
if (fs.existsSync(mainActivityPath)) {
  const javaCode = `package com.talipavci.cl9obd2;

import android.graphics.Color;
import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.parseColor("#040609"));
        getWindow().setNavigationBarColor(Color.parseColor("#040609"));
    }
}
`;
  fs.writeFileSync(mainActivityPath, javaCode, "utf8");
}

console.log("Android yapılandırması (Bluetooth, GPS, Ekran Açık Tutma, Android Auto) tamamlandı.");
